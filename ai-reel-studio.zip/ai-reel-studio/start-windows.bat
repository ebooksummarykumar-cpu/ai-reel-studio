@echo off
cd /d "%~dp0"
if not exist node_modules (
  echo Installing AI Reel Studio dependencies...
  call npm install
  if errorlevel 1 (
    echo Dependency installation failed. Check your internet connection and Node.js version.
    pause
    exit /b 1
  )
)
echo Starting AI Reel Studio...
call npm run dev
pause
