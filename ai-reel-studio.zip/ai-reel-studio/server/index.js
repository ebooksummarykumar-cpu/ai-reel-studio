import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import multer from 'multer';
import rateLimit from 'express-rate-limit';
import path from 'node:path';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import { probe, runFfmpeg, extractAudio, detectSilence } from './lib/ffmpeg.js';
import { EDL_SCHEMA, sanitizeEdl, buildAss } from './lib/edl.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
const STORAGE = path.join(__dirname, 'storage');
const UPLOADS = path.join(STORAGE, 'uploads');
const EXPORTS = path.join(STORAGE, 'exports');
for (const dir of [UPLOADS, EXPORTS]) fs.mkdirSync(dir, { recursive: true });

const app = express();
const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.HOST || '127.0.0.1';
const MAX_UPLOAD_MB = Number(process.env.MAX_UPLOAD_MB || 500);
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-3.8-flash';
const videos = new Map();
const audioAssets = new Map();
const exportsById = new Map();

app.disable('x-powered-by');
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' }, contentSecurityPolicy: false }));
app.use(express.json({ limit: '2mb' }));
app.use('/api/ai', rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: 'draft-8', legacyHeaders: false, handler: (_req, res) => apiError(res, 429, 'Too many AI requests. Please wait a minute and try again.') }));
app.use('/api/export', rateLimit({ windowMs: 60_000, limit: 5, standardHeaders: 'draft-8', legacyHeaders: false, handler: (_req, res) => apiError(res, 429, 'Too many exports. Please wait a minute and try again.') }));

const videoStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOADS),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase().slice(0, 10) || '.mp4';
    cb(null, `${randomUUID()}${ext}`);
  },
});
const uploadVideo = multer({
  storage: videoStorage,
  limits: { fileSize: MAX_UPLOAD_MB * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => { if (file.mimetype.startsWith('video/')) return cb(null, true); const error = new Error('Please choose a video file (MP4, MOV, WebM, etc.).'); error.status = 400; cb(error); },
});
const audioStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOADS),
  filename: (_req, file, cb) => cb(null, `${randomUUID()}${path.extname(file.originalname || '').toLowerCase().slice(0, 10) || '.audio'}`),
});
const uploadAudio = multer({
  storage: audioStorage,
  limits: { fileSize: MAX_UPLOAD_MB * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => { if (file.mimetype.startsWith('audio/')) return cb(null, true); const error = new Error('Please choose an audio file for your background music.'); error.status = 400; cb(error); },
});

function apiError(res, status, message, extra = {}) { return res.status(status).json({ error: message, ...extra }); }
function getVideo(id) { const item = videos.get(id); if (!item) throw Object.assign(new Error('Video not found. Upload it again.'), { status: 404 }); return item; }

async function updateEnv(values) {
  const envPath = path.join(ROOT, '.env');
  let content = '';
  try { content = await fsp.readFile(envPath, 'utf8'); } catch { /* first save */ }
  const lines = content.split(/\r?\n/).filter(Boolean);
  for (const [key, value] of Object.entries(values)) {
    if (!value) continue;
    const safe = `${key}=${JSON.stringify(value)}`;
    const i = lines.findIndex((line) => line.startsWith(`${key}=`));
    if (i >= 0) lines[i] = safe; else lines.push(safe);
    process.env[key] = value;
  }
  await fsp.writeFile(envPath, `${lines.join('\n')}\n`, { mode: 0o600 });
  try { await fsp.chmod(envPath, 0o600); } catch { /* Windows may not support POSIX modes */ }
}

app.get('/api/health', (_req, res) => res.json({ ok: true, model: GEMINI_MODEL }));
app.get('/api/settings/status', (_req, res) => res.json({
  hasGeminiKey: Boolean(process.env.GEMINI_API_KEY),
  hasSarvamKey: Boolean(process.env.SARVAM_API_KEY),
  model: GEMINI_MODEL,
}));
app.put('/api/settings', async (req, res, next) => {
  try {
    const gemini = typeof req.body?.geminiApiKey === 'string' ? req.body.geminiApiKey.trim() : '';
    const sarvam = typeof req.body?.sarvamApiKey === 'string' ? req.body.sarvamApiKey.trim() : '';
    if (!gemini && !sarvam) return apiError(res, 400, 'Enter at least one API key before saving.');
    if (gemini && gemini.length < 12) return apiError(res, 400, 'The Gemini API key looks too short. Check it and try again.');
    if (sarvam && sarvam.length < 12) return apiError(res, 400, 'The Sarvam API key looks too short. Check it and try again.');
    await updateEnv({ GEMINI_API_KEY: gemini, SARVAM_API_KEY: sarvam });
    res.json({ ok: true, hasGeminiKey: Boolean(process.env.GEMINI_API_KEY), hasSarvamKey: Boolean(process.env.SARVAM_API_KEY) });
  } catch (error) { next(error); }
});

app.post('/api/upload', (req, res, next) => {
  uploadVideo.single('video')(req, res, async (err) => {
    if (err) return next(err);
    try {
      if (!req.file) return apiError(res, 400, 'Choose a video to upload.');
      const meta = await probe(req.file.path);
      const duration = Number(meta.format?.duration || 0);
      if (!Number.isFinite(duration) || duration <= 0) {
        await fsp.unlink(req.file.path).catch(() => {});
        return apiError(res, 400, 'Could not read the video duration. Try an MP4 or MOV file.');
      }
      if (duration > 65) {
        await fsp.unlink(req.file.path).catch(() => {});
        return apiError(res, 400, 'This prototype accepts videos up to 65 seconds. Please trim this clip first.');
      }
      const videoStream = (meta.streams || []).find((s) => s.codec_type === 'video');
      const audioStream = (meta.streams || []).find((s) => s.codec_type === 'audio');
      const id = randomUUID();
      const waveformPath = audioStream ? path.join(UPLOADS, `${id}-wave.png`) : null;
      if (waveformPath) {
        try { await runFfmpeg(['-y', '-i', req.file.path, '-filter_complex', 'aformat=channel_layouts=mono,showwavespic=s=1400x56:colors=0xB987FF', '-frames:v', '1', waveformPath]); }
        catch { await fsp.unlink(waveformPath).catch(() => {}); }
      }
      const item = {
        id, path: req.file.path, waveformPath, originalName: req.file.originalname,
        mimeType: req.file.mimetype, duration,
        width: videoStream?.width || null, height: videoStream?.height || null,
        hasAudio: Boolean(audioStream), size: req.file.size,
      };
      videos.set(id, item);
      res.status(201).json({
        id, originalName: item.originalName, mimeType: item.mimeType,
        duration, width: item.width, height: item.height, hasAudio: item.hasAudio,
        warning: duration > 60 ? 'This clip is over 60 seconds. It is accepted for this prototype, but keep edits within the first 65 seconds.' : null,
        url: `/api/video/${id}`, waveformUrl: waveformPath ? `/api/waveform/${id}` : null,
      });
    } catch (error) { if (req.file?.path) await fsp.unlink(req.file.path).catch(() => {}); next(error); }
  });
});

app.get('/api/waveform/:id', (req, res) => {
  try {
    const video = getVideo(req.params.id);
    if (!video.waveformPath || !fs.existsSync(video.waveformPath)) return apiError(res, 404, 'No audio waveform is available for this clip.');
    res.type('png').sendFile(video.waveformPath);
  } catch (error) { apiError(res, error.status || 404, error.message); }
});

app.get('/api/video/:id', (req, res) => {
  try {
    const video = getVideo(req.params.id);
    res.type(video.mimeType);
    res.sendFile(video.path);
  } catch (error) { apiError(res, error.status || 404, error.message); }
});

app.post('/api/bgm', (req, res, next) => {
  uploadAudio.single('audio')(req, res, async (err) => {
    if (err) return next(err);
    try {
      if (!req.file) return apiError(res, 400, 'Choose an audio track.');
      const id = randomUUID();
      const waveformPath = path.join(UPLOADS, `${id}-wave.png`);
      try { await runFfmpeg(['-y', '-i', req.file.path, '-filter_complex', 'aformat=channel_layouts=mono,showwavespic=s=1400x56:colors=0xB987FF', '-frames:v', '1', waveformPath]); } catch { await fsp.unlink(waveformPath).catch(() => {}); }
      audioAssets.set(id, { id, path: req.file.path, waveformPath, originalName: req.file.originalname, mimeType: req.file.mimetype });
      res.status(201).json({ id, originalName: req.file.originalname, url: `/api/bgm/${id}`, waveformUrl: fs.existsSync(waveformPath) ? `/api/bgm/${id}/waveform` : null });
    } catch (error) { next(error); }
  });
});

async function sarvamTranscribe(audioPath) {
  if (!process.env.SARVAM_API_KEY) return null;
  const buffer = await fsp.readFile(audioPath);
  const form = new FormData();
  form.append('file', new Blob([buffer], { type: 'audio/mpeg' }), 'clip.mp3');
  form.append('model', 'saaras:v4');
  form.append('mode', 'codemix');
  form.append('language_code', 'unknown');
  form.append('with_timestamps', 'true');
  const response = await fetch('https://api.sarvam.ai/speech-to-text', {
    method: 'POST', headers: { 'api-subscription-key': process.env.SARVAM_API_KEY }, body: form,
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    const err = new Error(response.status === 429 ? 'Sarvam rate limit reached. Wait a moment and try again.' : (body.message || `Sarvam transcription failed (${response.status}).`));
    err.status = response.status === 429 ? 429 : 502;
    throw err;
  }
  const timestamps = body.timestamps || {};
  const starts = timestamps.start_time_seconds || [];
  const ends = timestamps.end_time_seconds || [];
  const words = timestamps.words || [];
  const captions = words.map((text, i) => ({ start: Number(starts[i] || 0), end: Number(ends[i] || starts[i] || 0) + 0.04, text: String(text), highlightWord: '' }))
    .filter((c) => c.end > c.start && c.text.trim());
  return { transcript: body.transcript || '', captions, languageCode: body.language_code || null };
}

async function geminiEdit({ video, prompt, audioPath, transcript }) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw Object.assign(new Error('Gemini API key missing. Open API Key Settings and add your key.'), { status: 400 });
  const audio = await fsp.readFile(audioPath);
  const systemPrompt = `You are an expert short-form video editor. Create an edit decision list for this video.\n` +
    `Video metadata: filename=${video.originalName}; duration=${video.duration.toFixed(2)} seconds; resolution=${video.width || 'unknown'}x${video.height || 'unknown'}; audio=${video.hasAudio ? 'present' : 'absent'}.\n` +
    `User instruction: ${prompt}\n` +
    `Transcript (may be empty): ${transcript || '(not available)'}\n` +
    `Return only structured JSON matching the supplied schema. All trimSegments and caption times must use ORIGINAL source-video seconds and stay between 0 and ${video.duration.toFixed(2)}. Keep trimSegments chronological, non-overlapping, and non-empty. Use playbackSpeed between 1.0 and 1.5. Captions should be concise, accurately transcribed from the audio, with natural Hindi/Hinglish spelling; do not invent speech. Use empty captions if the speech cannot be understood. Every caption must include start, end, text and highlightWord (empty string if none). Preserve the full clip unless the user asks for cuts or silence removal. Set bgmVolume to 0.15 unless asked otherwise.`;
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(GEMINI_MODEL)}:generateContent`, {
    method: 'POST', headers: { 'content-type': 'application/json', 'x-goog-api-key': key },
    body: JSON.stringify({
      contents: [{ role: 'user', parts: [
        { text: systemPrompt },
        { inline_data: { mime_type: 'audio/mpeg', data: audio.toString('base64') } },
      ] }],
      generationConfig: { temperature: 0.15, responseMimeType: 'application/json', responseJsonSchema: EDL_SCHEMA },
    }),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    let message = data.error?.message || `Gemini request failed (${response.status}).`;
    if (response.status === 429) message = 'Gemini rate limit reached. Wait a moment, then try again.';
    if ([400, 401, 403].includes(response.status)) message = `Gemini rejected the key or request: ${message}`;
    throw Object.assign(new Error(message), { status: response.status === 429 ? 429 : 502 });
  }
  const text = data.candidates?.[0]?.content?.parts?.map((p) => p.text || '').join('') || '';
  if (!text) throw Object.assign(new Error('Gemini returned an empty edit. Try a more specific instruction.'), { status: 502 });
  let parsed;
  try { parsed = JSON.parse(text.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '')); }
  catch { throw Object.assign(new Error('Gemini returned invalid edit JSON. Try again.'), { status: 502 }); }
  return parsed;
}

app.get('/api/bgm/:id', (req, res) => {
  const audio = audioAssets.get(req.params.id);
  if (!audio || !fs.existsSync(audio.path)) return apiError(res, 404, 'Background music not found. Upload it again.');
  res.type(audio.mimeType).sendFile(audio.path);
});

app.get('/api/bgm/:id/waveform', (req, res) => {
  const audio = audioAssets.get(req.params.id);
  if (!audio?.waveformPath || !fs.existsSync(audio.waveformPath)) return apiError(res, 404, 'No waveform is available for this audio track.');
  res.type('png').sendFile(audio.waveformPath);
});

app.post('/api/ai/edit', async (req, res, next) => {
  const tempAudio = path.join(UPLOADS, `${randomUUID()}.mp3`);
  try {
    const video = getVideo(String(req.body?.videoId || ''));
    const action = String(req.body?.action || 'chat');
    const prompt = String(req.body?.prompt || 'Make this short video more engaging.').slice(0, 2000);
    if (action === 'speed') {
      return res.json({ edl: sanitizeEdl({ playbackSpeed: 1.2, trimSegments: [{ start: 0, end: video.duration }], captions: [], assistantMessage: 'Playback speed set to 1.2× while preserving voice pitch.' }, video.duration), transcript: '' });
    }
    if (action !== 'speed' && !video.hasAudio) throw Object.assign(new Error('This video has no audio track. Add an audio track or use the 1.2× speed action.'), { status: 400 });
    if (action === 'remove-pauses') {
      const segments = await detectSilence(video.path, video.duration);
      const removed = Math.max(0, video.duration - segments.reduce((sum, s) => sum + s.end - s.start, 0));
      return res.json({ edl: sanitizeEdl({ playbackSpeed: 1, trimSegments: segments, captions: [], assistantMessage: removed > 0.3 ? `Removed about ${removed.toFixed(1)} seconds of long silent gaps.` : 'No long silent gaps were found. Your original timing is preserved.' }, video.duration), transcript: '' });
    }
    if (action === 'captions' && video.duration <= 29.9 && process.env.SARVAM_API_KEY) {
      await extractAudio(video.path, tempAudio);
      const sarvam = await sarvamTranscribe(tempAudio);
      const raw = {
        playbackSpeed: 1,
        trimSegments: [{ start: 0, end: video.duration }],
        captions: sarvam?.captions || [],
        audioSettings: { bgmVolume: 0.15, voiceBoost: false },
        assistantMessage: sarvam?.captions?.length ? 'Hindi/Hinglish captions added using speech recognition.' : 'Speech was not clear enough to create captions.',
      };
      return res.json({ edl: sanitizeEdl(raw, video.duration), transcript: sarvam?.transcript || '' });
    }
    await extractAudio(video.path, tempAudio);
    let transcript = '';
    if (action === 'captions' && process.env.SARVAM_API_KEY && video.duration > 29.9) {
      transcript = 'Sarvam quick transcription is limited to short clips; audio has been sent to Gemini for caption timing.';
    }
    const raw = await geminiEdit({ video, prompt, audioPath: tempAudio, transcript });
    res.json({ edl: sanitizeEdl(raw, video.duration), transcript });
  } catch (error) { next(error); }
  finally { await fsp.unlink(tempAudio).catch(() => {}); }
});

app.post('/api/export', async (req, res) => {
  let video;
  let assPath;
  try {
    video = getVideo(String(req.body?.videoId || ''));
    const edl = sanitizeEdl(req.body?.edl || {}, video.duration);
    const bgm = req.body?.bgmId ? audioAssets.get(String(req.body.bgmId)) : null;
    const outputId = randomUUID();
    const outputPath = path.join(EXPORTS, `${outputId}.mp4`);
    const outputDuration = edl.trimSegments.reduce((sum, s) => sum + s.end - s.start, 0) / edl.playbackSpeed;
    const filters = [];
    const hasAudio = video.hasAudio;
    const segmentLabels = [];
    edl.trimSegments.forEach((segment, index) => {
      filters.push(`[0:v]trim=start=${segment.start.toFixed(3)}:end=${segment.end.toFixed(3)},setpts=(PTS-STARTPTS)/${edl.playbackSpeed.toFixed(3)}[v${index}]`);
      if (hasAudio) {
        const boost = edl.audioSettings.voiceBoost ? ',volume=1.15' : '';
        filters.push(`[0:a]atrim=start=${segment.start.toFixed(3)}:end=${segment.end.toFixed(3)},asetpts=PTS-STARTPTS,atempo=${edl.playbackSpeed.toFixed(3)}${boost}[a${index}]`);
      }
      segmentLabels.push(`[v${index}]`);
      if (hasAudio) segmentLabels.push(`[a${index}]`);
    });
    const count = edl.trimSegments.length;
    filters.push(`${segmentLabels.join('')}concat=n=${count}:v=1:a=${hasAudio ? 1 : 0}[vcat]${hasAudio ? '[acat]' : ''}`);

    let videoLabel = 'vcat';
    if (edl.captions.length) {
      assPath = path.join(EXPORTS, `${outputId}.ass`);
      await fsp.writeFile(assPath, buildAss(edl), 'utf8');
      const escapedAss = assPath.replace(/\\/g, '/').replace(/:/g, '\\:').replace(/'/g, "\\'");
      filters.push(`[vcat]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1,subtitles='${escapedAss}'[vout]`);
    } else {
      filters.push('[vcat]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1[vout]');
    }

    const args = ['-y', '-i', video.path];
    if (bgm) { args.push('-stream_loop', '-1', '-i', bgm.path); }
    if (hasAudio && bgm) {
      filters.push(`[acat]volume=0.95[voice]`);
      filters.push(`[1:a]atrim=duration=${outputDuration.toFixed(3)},asetpts=PTS-STARTPTS,volume=${edl.audioSettings.bgmVolume.toFixed(3)}[music]`);
      filters.push('[voice][music]amix=inputs=2:duration=first:dropout_transition=2[aout]');
    } else if (hasAudio) {
      filters.push('[acat]anull[aout]');
    } else if (bgm) {
      filters.push(`[1:a]atrim=duration=${outputDuration.toFixed(3)},asetpts=PTS-STARTPTS,volume=${edl.audioSettings.bgmVolume.toFixed(3)}[aout]`);
    }
    args.push('-filter_complex', filters.join(';'), '-map', '[vout]');
    if (hasAudio || bgm) args.push('-map', '[aout]');
    args.push('-t', outputDuration.toFixed(3), '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '23', '-pix_fmt', 'yuv420p');
    if (hasAudio || bgm) args.push('-c:a', 'aac', '-b:a', '192k');
    args.push('-movflags', '+faststart', '-progress', 'pipe:1', '-nostats', outputPath);

    res.status(200);
    res.setHeader('Content-Type', 'application/x-ndjson; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.flushHeaders?.();
    let lastPercent = -1;
    await runFfmpeg(args, {
      onProgress: (timeUs) => {
        const percent = timeUs === Number.MAX_SAFE_INTEGER ? 100 : Math.max(0, Math.min(99, Math.round((timeUs / 1_000_000 / outputDuration) * 100)));
        if (percent !== lastPercent) { lastPercent = percent; res.write(`${JSON.stringify({ type: 'progress', percent })}\n`); }
      },
    });
    exportsById.set(outputId, outputPath);
    res.write(`${JSON.stringify({ type: 'done', percent: 100, downloadUrl: `/api/export/${outputId}` })}\n`);
    res.end();
  } catch (error) {
    if (res.headersSent) {
      res.write(`${JSON.stringify({ type: 'error', error: error.message || 'Export failed.' })}\n`);
      res.end();
    } else {
      apiError(res, error.status || 500, error.message || 'Export failed.');
    }
  } finally {
    if (assPath) await fsp.unlink(assPath).catch(() => {});
  }
});

app.get('/api/export/:id', (req, res) => {
  const outputPath = exportsById.get(req.params.id);
  if (!outputPath || !fs.existsSync(outputPath)) return apiError(res, 404, 'This export is no longer available. Run export again.');
  res.download(outputPath, 'ai-reel-studio-export.mp4');
});

// In production, serve the built React app from this same local server.
const dist = path.join(ROOT, 'dist');
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get(/.*/, (req, res, next) => req.path.startsWith('/api/') ? next() : res.sendFile(path.join(dist, 'index.html')));
}

app.use((error, _req, res, _next) => {
  const status = error.status || (error instanceof multer.MulterError || error.message?.startsWith('Please choose') ? 400 : 500);
  let message = error.message || 'Something went wrong.';
  if (error instanceof multer.MulterError && error.code === 'LIMIT_FILE_SIZE') message = `File is too large. The limit is ${MAX_UPLOAD_MB} MB.`;
  if (status === 429 && !message.toLowerCase().includes('rate')) message = 'Too many requests. Please wait a moment and try again.';
  if (!res.headersSent) res.status(status).json({ error: message });
  else res.end();
});

app.listen(PORT, HOST, () => {
  console.log(`AI Reel Studio API running at http://${HOST}:${PORT}`);
  console.log(`AI model: ${GEMINI_MODEL}. API keys: ${process.env.GEMINI_API_KEY ? 'Gemini configured' : 'Gemini not configured'}, ${process.env.SARVAM_API_KEY ? 'Sarvam configured' : 'Sarvam optional'}.`);
});
