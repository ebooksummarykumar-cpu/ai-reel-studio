# AI Reel Studio

A local, full-stack 9:16 short-video editor based on the supplied UI reference. The React editor talks to an Express API; FFmpeg runs on the server for accurate exports.

## Features

- Video upload with MIME, file-size and duration validation (up to 65 seconds; a warning appears above 60 seconds).
- 9:16 preview player, custom playback controls, live caption overlay and cut-aware preview playback.
- Quick actions: FFmpeg silence detection (gaps longer than 0.5 seconds), Hindi/Hinglish captions, 1.2× pacing, and user-supplied background music.
- Gemini structured EDL output for natural-language editing instructions and audio-aware captions.
- Optional Sarvam Saaras v4 speech-to-text for short clips (the synchronous REST endpoint is used only for clips shorter than 30 seconds).
- Multi-track timeline, source-audio waveform, timeline zoom, track visibility and undo/redo.
- MP4 rendering with cuts, speed changes, 9:16 crop, voice gain, BGM mixing and burned-in ASS captions.
- NDJSON progress stream and automatic MP4 download after rendering.

## Requirements

- Node.js 20 or newer.
- Internet access during `npm install` and when calling Gemini/Sarvam APIs.
- A Google Gemini API key for AI edits. Sarvam is optional; local silence detection and the 1.2× preset work without AI credentials.

The project uses the npm packages `ffmpeg-static` and `ffprobe-static`; you do not normally need to install FFmpeg separately.

## Run locally

1. Extract this project folder.
2. Open a terminal in the `ai-reel-studio` folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Start the frontend and backend:

   ```bash
   npm run dev
   ```

5. Open **http://127.0.0.1:5173** in your browser.
6. Click **API Key Settings**, enter a replacement Gemini key (and optional Sarvam key), then save.
7. Upload an MP4/MOV/WebM clip, run an edit action, and click **Export Video**.

For a single-server local run:

```bash
npm run build
npm start
```

Then open **http://127.0.0.1:8787**.

## API key handling

Keys entered in the settings modal are POSTed to the local backend and saved to the project-root `.env` file with restrictive file permissions where supported. They are not saved in browser `localStorage`, returned by the API, or printed in logs. `.env` is ignored by Git. Do not share it, put it in a public repository, or expose this development server to the internet.

You can alternatively copy `.env.example` to `.env` and add keys there before starting the backend. `GEMINI_MODEL` defaults to `gemini-3.8-flash` and can be changed in `.env` when Google changes model availability.

## Main API routes

| Route | Purpose |
| --- | --- |
| `GET /api/health` | Backend health and configured model |
| `GET /api/settings/status` | Returns configured/not-configured status only |
| `PUT /api/settings` | Save API keys server-side |
| `POST /api/upload` | Validate and inspect a video; make source waveform |
| `POST /api/bgm` | Upload a background-music audio file |
| `POST /api/ai/edit` | Return a sanitized Edit Decision List (EDL) |
| `POST /api/export` | Stream FFmpeg render progress as NDJSON |
| `GET /api/export/:id` | Download the rendered MP4 |

## Important implementation notes

- Gemini 1.5 Pro is retired, so the default model is the currently supported `gemini-3.8-flash`. The model name is configurable.
- Sarvam's synchronous REST transcription endpoint is intended for short clips (under 30 seconds); longer clips use Gemini audio input instead. Sarvam returns phrase/chunk timestamps, not true word-by-word timing.
- The preview uses the original uploaded media and jumps over removed sections. The rendered file is the final authority for the cut, speed, audio mix and burned captions.
- Background music is user-provided; the app does not download copyrighted music.
- Uploaded media and rendered files are held on the local server filesystem. The current prototype keeps project IDs in server memory, so restarting the backend clears the in-memory project/export index.
- This is a runnable local prototype, not a hardened multi-user public service. Before public deployment, add authentication, per-user storage isolation, a persistent job queue, quotas, cleanup/retention controls, HTTPS, and a proper secrets manager.

## Troubleshooting

- **`npm install` fails:** check that Node.js is current and the machine can reach the npm registry.
- **Gemini key rejected:** create/rotate a key in Google AI Studio, save it in API Key Settings, and verify the Gemini API is enabled for that key.
- **Sarvam key rejected:** check the Sarvam subscription key. Captions can fall back to Gemini when Sarvam is not configured or the clip is longer than 30 seconds.
- **FFmpeg export fails:** try a standard H.264/AAC MP4 input. Check the terminal output for the FFmpeg error; very high-resolution or damaged media may fail to decode.
- **No captions appear:** make sure the clip has audible speech, enable the Captions Track, and verify that the AI service returned caption entries.
