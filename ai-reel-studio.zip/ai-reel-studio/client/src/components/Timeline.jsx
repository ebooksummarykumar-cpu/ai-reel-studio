import { Captions, Eye, EyeOff, Film, Headphones, Minus, Plus, Redo2, Undo2 } from 'lucide-react';

const fmt = (n) => `${Math.floor(n / 60).toString().padStart(2, '0')}:${Math.floor(n % 60).toString().padStart(2, '0')}`;

export default function Timeline({ duration, edl, currentTime, onScrub, onUndo, onRedo, canUndo, canRedo, zoom, setZoom, tracks, toggleTrack, bgmName, waveformUrl }) {
  const segments = edl?.trimSegments?.length ? edl.trimSegments : (duration ? [{ start: 0, end: duration }] : []);
  const captions = edl?.captions || [];
  const zoomWidth = Math.max(100, zoom * 100);
  const playhead = duration ? Math.max(0, Math.min(100, currentTime / duration * 100)) : 0;
  const marks = Array.from({ length: Math.max(2, Math.ceil((duration || 60) / 10) + 1) }, (_, i) => i * 10).filter((v) => v <= (duration || 60) + 0.01);
  const toggle = (key) => <button className="track-eye" onClick={() => toggleTrack(key)} aria-label={`${tracks[key] ? 'Hide' : 'Show'} ${key} track`}>{tracks[key] ? <Eye size={15} /> : <EyeOff size={15} />}</button>;

  return (
    <section className="timeline-panel">
      <div className="timeline-header">
        <div className="timeline-title"><div className="timeline-title-icon"><Film size={16} /></div><strong>Timeline</strong></div>
        <div className="timeline-tools">
          <button className="tool-icon" disabled={!canUndo} onClick={onUndo} title="Undo"><Undo2 size={18} /></button>
          <button className="tool-icon" disabled={!canRedo} onClick={onRedo} title="Redo"><Redo2 size={18} /></button>
          <div className="zoom-control"><button className="tool-icon" onClick={() => setZoom(Math.max(0.75, zoom - 0.25))} title="Zoom out"><Minus size={16} /></button><input type="range" min="0.75" max="2.5" step="0.25" value={zoom} onChange={(e) => setZoom(Number(e.target.value))} aria-label="Timeline zoom" /><button className="tool-icon" onClick={() => setZoom(Math.min(2.5, zoom + 0.25))} title="Zoom in"><Plus size={16} /></button></div>
        </div>
      </div>
      <div className="timeline-body">
        <div className="track-labels">
          <div className="track-spacer" />
          <div className="track-label"><Film size={16} /><span>Video Track</span>{toggle('video')}</div>
          <div className="track-label"><Headphones size={16} /><span>Audio / Voiceover</span>{toggle('audio')}</div>
          <div className="track-label"><Captions size={16} /><span>Captions Track</span>{toggle('captions')}</div>
        </div>
        <div className="track-scroller">
          <div className="tracks-canvas" style={{ width: `${zoomWidth}%` }} onClick={(e) => {
            if (!duration) return;
            const r = e.currentTarget.getBoundingClientRect();
            const ratio = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
            onScrub(ratio * duration);
          }}>
            <div className="time-ruler">{marks.map((sec) => <span key={sec} style={{ left: `${duration ? sec / duration * 100 : 0}%` }}>{fmt(sec)}</span>)}</div>
            <div className="track-lane video-lane">
              {tracks.video && segments.map((s, i) => <div key={i} className="video-segment" style={{ left: `${s.start / (duration || 1) * 100}%`, width: `${(s.end - s.start) / (duration || 1) * 100}%` }} title={`${s.start.toFixed(1)}s – ${s.end.toFixed(1)}s`}><span>{i === 0 ? 'Clip' : `Cut ${i + 1}`}</span></div>)}
              {tracks.video && segments.length > 1 && <div className="cut-badge">{segments.length} kept segments</div>}
            </div>
            <div className="track-lane audio-lane">
              {tracks.audio && <div className="audio-clip">{waveformUrl && <img className="waveform-image" src={waveformUrl} alt="Audio waveform" />}<span>{bgmName ? `Original voice + ${bgmName}` : 'Original Audio'}</span></div>}
            </div>
            <div className="track-lane caption-lane">
              {tracks.captions && captions.map((c, i) => <div key={i} className="caption-block" style={{ left: `${c.start / (duration || 1) * 100}%`, width: `${Math.max(1.5, (c.end - c.start) / (duration || 1) * 100)}%` }} title={c.text}>{c.text}</div>)}
            </div>
            <div className="playhead" style={{ left: `${playhead}%` }}><span>{fmt(currentTime)}</span><i /></div>
          </div>
        </div>
      </div>
      <div className="timeline-footer"><span>{duration ? `${fmt(duration)} source duration` : 'Upload a video to begin'}</span><span>{edl?.playbackSpeed && edl.playbackSpeed !== 1 ? `${edl.playbackSpeed.toFixed(1)}× speed` : 'Original speed'}{edl?.captions?.length ? ` · ${edl.captions.length} captions` : ''}</span></div>
    </section>
  );
}
