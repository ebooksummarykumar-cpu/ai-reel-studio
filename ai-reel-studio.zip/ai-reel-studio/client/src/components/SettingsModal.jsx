import { useEffect, useState } from 'react';
import { KeyRound, LockKeyhole, X } from 'lucide-react';

export default function SettingsModal({ open, onClose, onSaved, apiStatus, notify }) {
  const [gemini, setGemini] = useState('');
  const [sarvam, setSarvam] = useState('');
  const [saving, setSaving] = useState(false);
  useEffect(() => { if (!open) { setGemini(''); setSarvam(''); setSaving(false); } }, [open]);
  if (!open) return null;

  async function save(event) {
    event.preventDefault();
    if (!gemini.trim() && !sarvam.trim()) {
      notify('Enter a new key in at least one field.', 'error');
      return;
    }
    setSaving(true);
    try {
      const response = await fetch('/api/settings', {
        method: 'PUT', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ geminiApiKey: gemini.trim(), sarvamApiKey: sarvam.trim() }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Could not save API keys.');
      onSaved(data);
      notify('API keys saved securely on the local server.', 'success');
      onClose();
    } catch (error) { notify(error.message, 'error'); }
    finally { setSaving(false); }
  }

  return (
    <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <section className="settings-modal" role="dialog" aria-modal="true" aria-labelledby="settings-title">
        <div className="modal-heading">
          <div className="modal-icon"><KeyRound size={21} /></div>
          <div><h2 id="settings-title">API Key Settings</h2><p>Connect your AI services</p></div>
          <button className="icon-button modal-close" onClick={onClose} aria-label="Close settings"><X size={19} /></button>
        </div>
        <form onSubmit={save} className="settings-form">
          <label className="field-label" htmlFor="gemini-key">Google Gemini API Key <span className="required-tag">Required for AI edits</span></label>
          <input id="gemini-key" type="password" autoComplete="off" value={gemini} onChange={(e) => setGemini(e.target.value)} placeholder={apiStatus?.hasGeminiKey ? 'Key already saved · enter to replace' : 'Paste your Gemini API key'} />
          <div className="field-help">Model: <code>{apiStatus?.model || 'gemini-3.8-flash'}</code>. Key is never returned to the browser.</div>

          <label className="field-label sarvam-label" htmlFor="sarvam-key">Sarvam AI API Key <span className="optional-tag">Optional · Hindi / Hinglish</span></label>
          <input id="sarvam-key" type="password" autoComplete="off" value={sarvam} onChange={(e) => setSarvam(e.target.value)} placeholder={apiStatus?.hasSarvamKey ? 'Key already saved · enter to replace' : 'Paste your Sarvam API key'} />
          <div className="field-help">Used for short Hindi/Hinglish transcription. Gemini handles longer clips.</div>
          <div className="secure-note"><LockKeyhole size={16} /><span>Stored in the backend <code>.env</code> file on this machine. Never share that file or commit it to Git.</span></div>
          <div className="modal-footer">
            <span className="key-status"><i className={apiStatus?.hasGeminiKey ? 'status-dot ready' : 'status-dot'} />Gemini {apiStatus?.hasGeminiKey ? 'connected' : 'not connected'}</span>
            <button className="primary-button" type="submit" disabled={saving}>{saving ? 'Saving…' : 'Save API Keys'}</button>
          </div>
        </form>
      </section>
    </div>
  );
}
