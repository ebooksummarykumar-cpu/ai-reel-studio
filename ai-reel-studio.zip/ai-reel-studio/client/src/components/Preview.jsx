import { Maximize, Pause, Play, SkipBack, SkipForward, Volume2 } from 'lucide-react';
import { useEffect, useRef } from 'react';

function CaptionText({ caption }) {
  if (!caption?.highlightWord) return <>{caption?.text}</>;
  const text = caption.text;
  const idx = text.toLocaleLowerCase().indexOf(caption.highlightWord.toLocaleLowerCase());
  if (idx < 0) return <>{text}</>;
  return <>{text.slice(0, idx)}<strong>{text.slice(idx, idx + caption.highlightWord.length)}</strong>{text.slice(idx + caption.highlightWord.length)}</>;
}

export default function Preview({ video, videoRef, playing, setPlaying, currentTime, setCurrentTime, edl, onScrub, tracks, bgm }) {
  const bgmRef = useRef(null);
  const caption = tracks.captions ? edl?.captions?.find((c) => currentTime >= c.start && currentTime <= c.end) : null;
  const duration = video?.duration || 0;
  useEffect(() => {
    if (videoRef.current && edl?.playbackSpeed) {
      videoRef.current.playbackRate = edl.playbackSpeed;
      videoRef.current.preservesPitch = true;
    }
    if (bgmRef.current) {
      bgmRef.current.volume = edl?.audioSettings?.bgmVolume ?? 0.15;
      bgmRef.current.playbackRate = edl?.playbackSpeed || 1;
      bgmRef.current.preservesPitch = true;
      if (!bgm || bgm.active === false) bgmRef.current.pause();
    }
  }, [edl?.playbackSpeed, edl?.audioSettings?.bgmVolume, bgm, videoRef]);

  function outputTimeForSource(sourceTime) {
    const segments = edl?.trimSegments?.length ? edl.trimSegments : (video ? [{ start: 0, end: video.duration }] : []);
    let elapsed = 0;
    for (const segment of segments) {
      if (sourceTime >= segment.start && sourceTime <= segment.end) return (elapsed + sourceTime - segment.start) / (edl?.playbackSpeed || 1);
      elapsed += segment.end - segment.start;
    }
    return null;
  }
  function syncBgm(sourceTime) {
    if (!bgm?.url || bgm.active === false || !bgmRef.current) return;
    const outputTime = outputTimeForSource(sourceTime);
    if (outputTime === null) return;
    bgmRef.current.playbackRate = edl?.playbackSpeed || 1;
    const duration = bgmRef.current.duration;
    const targetTime = Number.isFinite(duration) && duration > 0 ? outputTime % duration : outputTime;
    if (Math.abs(bgmRef.current.currentTime - targetTime) > 0.3) bgmRef.current.currentTime = targetTime;
  }
  function onVideoPlay() {
    setPlaying(true);
    if (bgm?.url && bgm.active !== false && bgmRef.current) {
      syncBgm(videoRef.current?.currentTime || 0);
      bgmRef.current.play().catch(() => {});
    }
  }
  function onVideoPause() { setPlaying(false); bgmRef.current?.pause(); }

  function togglePlay() {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      const first = edl?.trimSegments?.[0];
      if (first && videoRef.current.currentTime < first.start) videoRef.current.currentTime = first.start;
      videoRef.current.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
    } else { videoRef.current.pause(); setPlaying(false); }
  }
  const seek = (offset) => {
    if (!videoRef.current || !duration) return;
    onScrub(Math.max(0, Math.min(duration, currentTime + offset)));
  };
  const format = (n) => `${Math.floor(n / 60).toString().padStart(2, '0')}:${Math.floor(n % 60).toString().padStart(2, '0')}`;

  return (
    <section className="preview-panel">
      <div className="preview-stage">
        {video ? (
          <div className="video-frame">
            <video ref={videoRef} src={video.url} playsInline preload="metadata" onTimeUpdate={(e) => { setCurrentTime(e.currentTarget.currentTime); syncBgm(e.currentTarget.currentTime); }} onEnded={onVideoPause} onPause={onVideoPause} onPlay={onVideoPlay} />
            {bgm?.url && <audio ref={bgmRef} src={bgm.url} preload="auto" loop onLoadedMetadata={() => syncBgm(videoRef.current?.currentTime || 0)} />}
            {caption && <div className="caption-overlay"><CaptionText caption={caption} /></div>}
          </div>
        ) : (
          <div className="preview-empty"><div className="empty-play"><Play size={28} fill="currentColor" /></div><strong>Your video preview</strong><span>Upload a clip to start editing</span><span className="empty-aspect">9:16 VERTICAL CANVAS</span></div>
        )}
      </div>
      <div className="player-controls">
        <button className="play-control" onClick={togglePlay} disabled={!video} aria-label={playing ? 'Pause video' : 'Play video'}>{playing ? <Pause size={19} fill="currentColor" /> : <Play size={19} fill="currentColor" />}</button>
        <button className="control-icon" onClick={() => seek(-5)} disabled={!video} aria-label="Back 5 seconds"><SkipBack size={18} /></button>
        <button className="control-icon" onClick={() => seek(5)} disabled={!video} aria-label="Forward 5 seconds"><SkipForward size={18} /></button>
        <div className="player-time"><strong>{format(currentTime)}</strong><span> / {format(duration)}</span></div>
        <div className="player-divider" />
        <div className="aspect-selector">9:16 <span>⌄</span></div>
        <button className="control-icon volume-control" onClick={() => { if (videoRef.current) videoRef.current.muted = !videoRef.current.muted; }} disabled={!video} aria-label="Toggle mute"><Volume2 size={18} /></button>
        <button className="control-icon" onClick={() => videoRef.current?.requestFullscreen?.()} disabled={!video} aria-label="Fullscreen"><Maximize size={17} /></button>
      </div>
      {video && <div className="preview-scrub"><input type="range" min="0" max={duration || 1} step="0.05" value={currentTime} onChange={(e) => onScrub(Number(e.target.value))} aria-label="Scrub video" /></div>}
    </section>
  );
}
