import { Crown, Play, Rocket, Settings2 } from 'lucide-react';

export default function TopBar({ onSettings, onExport, exporting, progress, hasVideo }) {
  return (
    <header className="topbar">
      <div className="brand-lockup">
        <div className="brand-mark"><Play size={25} fill="currentColor" strokeWidth={1.5} /></div>
        <div>
          <div className="brand-name">AI Reel <span>Studio</span></div>
          <div className="brand-tagline">Create · Edit · Go Viral</div>
        </div>
      </div>
      <div className="topbar-actions">
        <button className="settings-button" onClick={onSettings}><Settings2 size={18} /> <span>API Key Settings</span></button>
        <button className="export-button" onClick={onExport} disabled={!hasVideo || exporting}>
          <Rocket size={17} />
          <span>{exporting ? `Rendering ${progress}%` : 'Export Video'}</span>
        </button>
        <div className="crown-mark" title="AI Reel Studio"><Crown size={23} fill="currentColor" /></div>
      </div>
    </header>
  );
}
