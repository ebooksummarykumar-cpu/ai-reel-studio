import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Bot, Captions, Check, ChevronRight, CloudUpload, Folder, Grid2X2, Home,
  MessageSquare, Music2, PauseCircle, Play, Scissors, Settings, Sparkles,
  WandSparkles, Zap, Gauge, AudioLines, FileVideo, Paperclip, Send, X,
} from 'lucide-react';
import TopBar from './components/TopBar.jsx';
import SettingsModal from './components/SettingsModal.jsx';
import Timeline from './components/Timeline.jsx';
import Preview from './components/Preview.jsx';

const QUICK_ACTIONS = [
  { id: 'remove-pauses', title: 'Remove Awkward Pauses', icon: AudioLines, description: 'Detect and cut silences over 0.5 seconds' },
  { id: 'captions', title: 'Auto-Add Hindi/Hinglish Captions', icon: Captions, description: 'Transcribe speech and sync subtitles' },
  { id: 'speed', title: '1.2× Fast Pacing', icon: Gauge, description: 'Speed up the clip while preserving pitch' },
  { id: 'bgm', title: 'Add Upbeat BGM', icon: Music2, description: 'Add your own music under the voiceover' },
];
const INITIAL_EDL = { playbackSpeed: 1, trimSegments: [], captions: [], audioSettings: { bgmVolume: 0.15, voiceBoost: false }, assistantMessage: '' };

function timeLabel(value) { return `${Math.floor(value / 60).toString().padStart(2, '0')}:${Math.floor(value % 60).toString().padStart(2, '0')}`; }

export default function App() {
  const videoRef = useRef(null);
  const fileInputRef = useRef(null);
  const bgmInputRef = useRef(null);
  const undoStack = useRef([]);
  const redoStack = useRef([]);
  const [video, setVideo] = useState(null);
  const [bgm, setBgm] = useState(null);
  const [edl, setEdl] = useState(INITIAL_EDL);
  const [chat, setChat] = useState([{ role: 'assistant', text: 'Hi! Upload a video and tell me what you want to improve. I can cut pauses, add Hindi/Hinglish captions, adjust pacing and mix music.', time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }]);
  const [prompt, setPrompt] = useState('');
  const [uploading, setUploading] = useState(false);
  const [working, setWorking] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [apiStatus, setApiStatus] = useState({ hasGeminiKey: false, hasSarvamKey: false, model: 'gemini-3.8-flash' });
  const [toast, setToast] = useState(null);
  const [exporting, setExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [tracks, setTracks] = useState({ video: true, audio: true, captions: true });
  const [activeNav, setActiveNav] = useState('Home');
  const [showTemplates, setShowTemplates] = useState(false);

  const notify = useCallback((message, type = 'info') => {
    setToast({ message, type, id: Date.now() });
    window.clearTimeout(notify.timer);
    notify.timer = window.setTimeout(() => setToast(null), 4400);
  }, []);

  useEffect(() => {
    fetch('/api/settings/status').then((r) => r.json()).then(setApiStatus).catch(() => {});
  }, []);

  const updateEdl = useCallback((next) => {
    undoStack.current.push(edl);
    if (undoStack.current.length > 40) undoStack.current.shift();
    redoStack.current = [];
    setEdl(next);
  }, [edl]);

  const undo = () => {
    if (!undoStack.current.length) return;
    redoStack.current.push(edl);
    setEdl(undoStack.current.pop());
  };
  const redo = () => {
    if (!redoStack.current.length) return;
    undoStack.current.push(edl);
    setEdl(redoStack.current.pop());
  };

  async function handleUpload(file) {
    if (!file) return;
    if (!file.type.startsWith('video/')) { notify('Please select a video file, such as MP4 or MOV.', 'error'); return; }
    const form = new FormData();
    form.append('video', file);
    setUploading(true);
    try {
      const response = await fetch('/api/upload', { method: 'POST', body: form });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Video upload failed.');
      setVideo(data);
      setCurrentTime(0);
      setPlaying(false);
      setBgm(null);
      undoStack.current = [];
      redoStack.current = [];
      setEdl({ ...INITIAL_EDL, trimSegments: [{ start: 0, end: data.duration }] });
      setChat([{ role: 'assistant', text: `Video loaded: ${data.originalName}. Duration ${data.duration.toFixed(1)} seconds. Choose a Quick AI Action or tell me how you want to edit it.`, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }]);
      notify(data.warning || 'Video uploaded and ready to edit.', data.warning ? 'warning' : 'success');
    } catch (error) { notify(error.message, 'error'); }
    finally { setUploading(false); if (fileInputRef.current) fileInputRef.current.value = ''; }
  }

  async function uploadBgm(file) {
    if (!file) return;
    if (!file.type.startsWith('audio/')) { notify('Choose an audio file for background music.', 'error'); return; }
    const form = new FormData();
    form.append('audio', file);
    try {
      const response = await fetch('/api/bgm', { method: 'POST', body: form });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Could not upload music.');
      setBgm({ ...data, active: true });
      notify(`Background music ready: ${data.originalName}. It will be mixed at 15% volume.`, 'success');
    } catch (error) { notify(error.message, 'error'); }
    finally { if (bgmInputRef.current) bgmInputRef.current.value = ''; }
  }

  async function applyAIEdit({ action = 'chat', text, promptText } = {}) {
    if (!video) { notify('Upload a video before using AI tools.', 'warning'); return; }
    const message = promptText || text || QUICK_ACTIONS.find((item) => item.id === action)?.title || 'Improve this video';
    setChat((items) => [...items, { role: 'user', text: message, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }]);
    setWorking(true);
    try {
      const response = await fetch('/api/ai/edit', {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ videoId: video.id, action, prompt: message }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'AI editing failed.');
      updateEdl(data.edl);
      setChat((items) => [...items, { role: 'assistant', text: data.edl.assistantMessage || 'Edit decisions updated.', transcript: data.transcript || '', time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }]);
      notify('Edit decisions applied to the preview and timeline.', 'success');
    } catch (error) {
      setChat((items) => [...items, { role: 'assistant', text: `I couldn't complete that edit: ${error.message}`, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }]);
      notify(error.message, 'error');
    } finally { setWorking(false); }
  }

  function runQuickAction(action) {
    if (action === 'bgm') {
      if (bgm) {
        setBgm({ ...bgm, active: !bgm.active });
        notify(bgm.active === false ? 'Background music enabled at 15% volume.' : 'Background music disabled.', 'success');
      } else {
        notify('Choose an audio file to use as your background music.', 'info');
        bgmInputRef.current?.click();
      }
      return;
    }
    const prompts = {
      'remove-pauses': 'Remove awkward pauses by detecting silent gaps longer than 0.5 seconds. Keep natural speech intact.',
      captions: 'Add accurate Hindi/Hinglish captions with phrase-level timestamps. Highlight one key word in each caption where appropriate.',
      speed: 'Set playback speed to 1.2x while preserving the voice pitch. Keep the full video.',
    };
    applyAIEdit({ action, promptText: prompts[action] });
  }

  function mapScrubTime(time) {
    if (!video || !videoRef.current) return;
    const segments = edl.trimSegments?.length ? edl.trimSegments : [{ start: 0, end: video.duration }];
    let target = Math.max(0, Math.min(video.duration, time));
    const inSegment = segments.find((s) => target >= s.start && target <= s.end);
    if (!inSegment) {
      const next = segments.find((s) => s.start > target);
      target = next ? next.start : (segments.at(-1)?.end || 0);
    }
    videoRef.current.currentTime = target;
    setCurrentTime(target);
  }

  function handleTimeUpdate(time) {
    setCurrentTime(time);
    if (!playing || !edl.trimSegments?.length || !videoRef.current) return;
    const segments = edl.trimSegments;
    const index = segments.findIndex((s) => time >= s.start - 0.02 && time <= s.end + 0.02);
    if (index === -1) {
      const next = segments.find((s) => s.start > time + 0.02);
      if (next) videoRef.current.currentTime = next.start;
      else { videoRef.current.pause(); setPlaying(false); }
    } else if (time >= segments[index].end - 0.025) {
      const next = segments[index + 1];
      if (next) videoRef.current.currentTime = next.start;
      else { videoRef.current.pause(); setPlaying(false); }
    }
  }

  async function exportVideo() {
    if (!video) { notify('Upload a video before exporting.', 'warning'); return; }
    setExporting(true); setExportProgress(0);
    try {
      const response = await fetch('/api/export', {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ videoId: video.id, edl, bgmId: bgm?.active === false ? null : bgm?.id }),
      });
      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        throw new Error(error.error || 'Could not start rendering.');
      }
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let downloadUrl = null;
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';
        for (const line of lines) {
          if (!line.trim()) continue;
          const event = JSON.parse(line);
          if (event.type === 'progress') setExportProgress(event.percent);
          if (event.type === 'done') { setExportProgress(100); downloadUrl = event.downloadUrl; }
          if (event.type === 'error') throw new Error(event.error || 'Render failed.');
        }
      }
      if (!downloadUrl) throw new Error('The render finished without a download link.');
      const anchor = document.createElement('a');
      anchor.href = downloadUrl;
      anchor.download = 'ai-reel-studio-export.mp4';
      document.body.appendChild(anchor); anchor.click(); anchor.remove();
      notify('Your MP4 is ready and the download has started.', 'success');
    } catch (error) { notify(error.message, 'error'); }
    finally { setExporting(false); }
  }

  function sendChat(event) {
    event.preventDefault();
    const text = prompt.trim();
    if (!text || working) return;
    setPrompt('');
    applyAIEdit({ action: 'chat', promptText: text });
  }

  const statusLabel = useMemo(() => apiStatus.hasGeminiKey ? 'AI Connected' : 'Add API Key', [apiStatus]);

  return (
    <div className="app-shell">
      <TopBar onSettings={() => setSettingsOpen(true)} onExport={exportVideo} exporting={exporting} progress={exportProgress} hasVideo={Boolean(video)} />
      <div className="workspace">
        <aside className="sidebar">
          <div className="nav-items">
            {[{ label: 'Home', icon: Home }, { label: 'Projects', icon: Folder }, { label: 'Templates', icon: Grid2X2 }, { label: 'AI Tools', icon: Sparkles }, { label: 'Settings', icon: Settings }].map(({ label, icon: Icon }) => (
              <button key={label} className={`nav-item ${activeNav === label ? 'active' : ''}`} onClick={() => {
                setActiveNav(label);
                if (label === 'Settings') setSettingsOpen(true);
                else if (label === 'Templates') setShowTemplates((v) => !v);
                else if (label === 'AI Tools') document.getElementById('quick-actions')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
                else if (label === 'Projects') notify(video ? `Current session: ${video.originalName}` : 'Your projects appear here after you upload a video.', 'info');
              }}><Icon size={20} /><span>{label}</span></button>
            ))}
          </div>
          <div className="sidebar-bottom">
            <div className="sidebar-status"><span className={apiStatus.hasGeminiKey ? 'status-dot ready' : 'status-dot'} />{apiStatus.hasGeminiKey ? 'AI connected' : 'API key needed'}</div>
            <button className="go-pro-card" onClick={() => notify('This local prototype has no subscription or payment flow.', 'info')}><Sparkles size={18} /><strong>Studio Tools</strong><span>Local editing workspace</span></button>
          </div>
        </aside>

        <main className="editor-area">
          <div className="editor-grid">
            <section className="left-panel panel">
              <div className="section-heading"><div className="heading-icon folder-icon"><Folder size={19} /></div><h2>Upload Your Video</h2></div>
              <button className={`upload-dropzone ${uploading ? 'is-uploading' : ''}`} onClick={() => fileInputRef.current?.click()} onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); handleUpload(e.dataTransfer.files?.[0]); }}>
                {video ? <><div className="upload-complete"><Check size={24} /></div><strong>{video.originalName}</strong><span>{timeLabel(video.duration)} · {video.width || '—'} × {video.height || '—'}</span><small>Click or drop to replace video</small></> : <><CloudUpload size={46} strokeWidth={1.7} /><strong>{uploading ? 'Uploading your video…' : 'Drag & Drop Video Here'}</strong><span>or click to browse</span></>}
              </button>
              <input ref={fileInputRef} className="hidden-input" type="file" accept="video/*" onChange={(e) => handleUpload(e.target.files?.[0])} />
              <div className="upload-spec">MP4 / MOV / WebM · Up to 65 seconds · 9:16 export</div>

              <div className="quick-heading" id="quick-actions"><Zap size={20} fill="#ffc928" color="#ffc928" /><h2>Quick AI Actions</h2></div>
              <div className="quick-actions-list">
                {QUICK_ACTIONS.map(({ id, title, icon: Icon, description }) => (
                  <button key={id} className="quick-action" onClick={() => runQuickAction(id)} disabled={working || uploading} title={description}>
                    <span className={`quick-action-icon ${id}`}><Icon size={20} /></span><span className="quick-action-text">{title}</span><ChevronRight size={17} className="quick-chevron" />
                  </button>
                ))}
              </div>
              <input ref={bgmInputRef} type="file" className="hidden-input" accept="audio/*" onChange={(e) => uploadBgm(e.target.files?.[0])} />
              {bgm && <div className="bgm-file"><Music2 size={14} /><span>{bgm.originalName}</span><button onClick={() => setBgm(null)} aria-label="Remove background music"><X size={14} /></button></div>}
              {showTemplates && <div className="template-strip"><strong>Caption templates</strong><button onClick={() => { setTracks((v) => ({ ...v, captions: true })); setShowTemplates(false); notify('Bold yellow-highlight caption style is active.', 'success'); }}>Bold viral captions <Check size={13} /></button></div>}
            </section>

            <Preview video={video} videoRef={videoRef} playing={playing} setPlaying={setPlaying} currentTime={currentTime} setCurrentTime={handleTimeUpdate} edl={edl} onScrub={mapScrubTime} tracks={tracks} bgm={bgm} />

            <section className="chat-panel panel">
              <div className="chat-header"><div className="chat-heading"><div className="chat-icon"><MessageSquare size={17} fill="currentColor" /></div><h2>AI Prompt Chat</h2></div><div className="online-status"><i />Online</div></div>
              <div className="chat-messages">
                {chat.map((item, i) => <div className={`message-row ${item.role}`} key={i}>
                  {item.role === 'assistant' && <div className="assistant-avatar"><Sparkles size={18} fill="currentColor" /></div>}
                  <div className="message-bubble">
                    <p>{item.text}</p>
                    {item.transcript && <div className="transcript-note">Transcript: {item.transcript}</div>}
                    <small>{item.time || ''} {item.role === 'user' && <Check size={12} />}</small>
                  </div>
                </div>)}
                {working && <div className="message-row assistant"><div className="assistant-avatar pulse"><Sparkles size={18} /></div><div className="message-bubble typing"><span /><span /><span /></div></div>}
              </div>
              <form className="chat-composer" onSubmit={sendChat}>
                <WandSparkles size={16} className="composer-sparkle" />
                <input value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="Type your editing instructions…" disabled={working} />
                <button type="submit" disabled={working || !prompt.trim()}><Send size={15} /><span>Send / Generate</span></button>
              </form>
              <div className="chat-footer"><span>{statusLabel}</span><span>AI edits use your uploaded audio</span></div>
            </section>
          </div>

          <Timeline duration={video?.duration || 0} edl={edl} currentTime={currentTime} onScrub={mapScrubTime} onUndo={undo} onRedo={redo} canUndo={undoStack.current.length > 0} canRedo={redoStack.current.length > 0} zoom={zoom} setZoom={setZoom} tracks={tracks} toggleTrack={(key) => setTracks((prev) => ({ ...prev, [key]: !prev[key] }))} bgmName={bgm?.originalName} waveformUrl={video?.waveformUrl} />
          <div className="workspace-footnote"><span><FileVideo size={13} />{video ? `${video.originalName} · ${timeLabel(video.duration)}` : 'No video loaded'}</span><span>Local processing · MP4 export · {apiStatus.model}</span></div>
        </main>
      </div>

      <SettingsModal open={settingsOpen} onClose={() => setSettingsOpen(false)} apiStatus={apiStatus} notify={notify} onSaved={(data) => setApiStatus((prev) => ({ ...prev, ...data }))} />
      {toast && <div className={`toast toast-${toast.type}`} role="status"><span className="toast-dot" />{toast.message}<button onClick={() => setToast(null)} aria-label="Dismiss notification"><X size={15} /></button></div>}
      {exporting && <div className="render-overlay"><div className="render-card"><div className="render-spinner" /><strong>Rendering your video</strong><span>Applying cuts, audio and styled captions…</span><div className="render-progress"><i style={{ width: `${exportProgress}%` }} /></div><b>{exportProgress}%</b></div></div>}
    </div>
  );
}
